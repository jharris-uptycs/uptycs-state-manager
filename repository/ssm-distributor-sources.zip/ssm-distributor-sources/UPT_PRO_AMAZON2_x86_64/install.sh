#!/bin/bash
#
# Distributor package installer - Amazon Linux 2 / RPM based distros
#
filename=assets-uptycs-protect-5.7.0.25-Uptycs.rpm

rpm -ivh "$filename"